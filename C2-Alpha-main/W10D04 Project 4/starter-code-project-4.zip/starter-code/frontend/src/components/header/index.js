import React from 'react';

const Header = () => {
	return <div className="App">Header component</div>;
};

export default Header;
