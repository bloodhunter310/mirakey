import React from 'react';
import { Route } from 'react-router-dom';

const App = () => {
	return <div className="App">App component</div>;
};

export default App;
