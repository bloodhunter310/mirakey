import React from 'react';

const Dashboard = () => {
	return <div className="App">Dashboard component</div>;
};

export default Dashboard;
