import React from 'react';

const Footer = () => {
	return <div className="App">Footer component</div>;
};

export default Footer;
