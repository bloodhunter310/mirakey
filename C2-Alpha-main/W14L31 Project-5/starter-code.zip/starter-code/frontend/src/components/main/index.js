import React from 'react';

const Main = () => {
	return <div className="App">App component</div>;
};

export default Main;
